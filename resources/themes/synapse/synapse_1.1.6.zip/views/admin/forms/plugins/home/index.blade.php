<div>

    <div class="mb-4">
        @include('admin.components.forms.switch', [
            'direction' => 'row',
            'id' => $id.'[server][show]',
            'name' => trans('theme::admin.server_button_hide')
        ])
    </div>

    @include('admin.components.forms.textaera', [
        'id' => $id.'[text]',
        'wysiwyg' => true,
        'name' => "Text home",
    ])
</div>
