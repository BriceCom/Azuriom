<?php

namespace Azuriom\Plugin\Hunt\Controllers\Admin;

use Azuriom\Http\Controllers\Controller;
use Azuriom\Models\Role;
use Azuriom\Models\Server;
use Azuriom\Plugin\Hunt\Models\Hunt;
use Azuriom\Plugin\Hunt\Models\HuntReward;
use Azuriom\Plugin\Hunt\Requests\RewardRequest;
use Azuriom\Plugin\ScratchGame\Models\ScratchCard;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class RewardController extends Controller
{
    private function scratchGameData(): array
    {
        $cards = [];

        $scratchGameEnabled = plugins()->isEnabled('scratch-game');

        if ($scratchGameEnabled) {
            $cards = scratch_game_available_cards();
        }

        return [
            'scratchGameEnabled' => $scratchGameEnabled,
            'scratchCards' => $cards,
        ];
    }
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $hunt_id = $request->input('hunt_id');
        $status = $request->input('status');

        $rewards = HuntReward::with(['hunt', 'roles', 'servers'])
            ->when($search, fn (Builder $query) => $query->search($search))
            ->when($hunt_id, fn (Builder $query) => $query->where('hunt_id', $hunt_id))
            ->when($status === 'enabled', fn (Builder $query) => $query->where('is_enabled', true))
            ->when($status === 'disabled', fn (Builder $query) => $query->where('is_enabled', false))
            ->latest()
            ->paginate();

        $hunts = Hunt::orderBy('name')->get(['id', 'name']);

        return view('hunt::admin.rewards.index', [
            'search' => $search,
            'hunt_id' => $hunt_id,
            'status' => $status,
            'rewards' => $rewards,
            'hunts' => $hunts,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $hunt_id = $request->input('hunt_id');
        $hunt = $hunt_id ? Hunt::findOrFail($hunt_id) : null;

        return view('hunt::admin.rewards.create', array_merge([
            'hunt' => $hunt,
            'hunts' => Hunt::orderBy('name')->get(['id', 'name']),
            'roles' => Role::orderBy('name')->get(),
            'servers' => Server::executable()->get(),
        ], $this->scratchGameData()));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(RewardRequest $request)
    {
        $data = Arr::except($request->validated(), ['roles', 'servers']);

        $reward = HuntReward::create($data);

        $reward->roles()->sync($request->input('roles', []));
        $reward->servers()->sync($request->input('servers', []));

        return to_route('hunt.admin.rewards.index', ['hunt_id' => $reward->hunt_id])
            ->with('success', trans('hunt::admin.rewards.status.created'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(HuntReward $reward)
    {
        $reward->load(['hunt', 'roles', 'servers']);

        return view('hunt::admin.rewards.edit', array_merge([
            'reward' => $reward,
            'hunts' => Hunt::orderBy('name')->get(['id', 'name']),
            'roles' => Role::orderBy('name')->get(),
            'servers' => Server::executable()->get(),
        ], $this->scratchGameData()));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(RewardRequest $request, HuntReward $reward)
    {
        $reward->update(Arr::except($request->validated(), ['roles', 'servers']));

        $reward->roles()->sync($request->input('roles', []));
        $reward->servers()->sync($request->input('servers', []));

        return to_route('hunt.admin.rewards.index', ['hunt_id' => $reward->hunt_id])
            ->with('success', trans('hunt::admin.rewards.status.updated'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(HuntReward $reward)
    {
        $hunt_id = $reward->hunt_id;
        $reward->delete();

        return to_route('hunt.admin.rewards.index', ['hunt_id' => $hunt_id])
            ->with('success', trans('hunt::admin.rewards.status.deleted'));
    }

    /**
     * Toggle reward enabled status.
     */
    public function toggleEnabled(HuntReward $reward)
    {
        $reward->update(['is_enabled' => !$reward->is_enabled]);

        $message = $reward->is_enabled
            ? trans('hunt::admin.rewards.status.enabled')
            : trans('hunt::admin.rewards.status.disabled');

        return back()->with('success', $message);
    }

    /**
     * Clone a reward to another hunt.
     */
    public function clone(Request $request, HuntReward $reward)
    {
        $request->validate([
            'target_hunt_id' => ['required', 'exists:hunt_hunts,id'],
        ]);

        $newReward = $reward->replicate();
        $newReward->hunt_id = $request->input('target_hunt_id');
        $newReward->name .= ' (Copy)';
        $newReward->save();

        $newReward->roles()->sync($reward->roles->pluck('id'));
        $newReward->servers()->sync($reward->servers->pluck('id'));

        return back()->with('success', trans('hunt::admin.rewards.status.cloned'));
    }

    /**
     * Bulk enable/disable rewards.
     */
    public function bulkToggle(Request $request)
    {
        $request->validate([
            'rewards' => ['required', 'array'],
            'rewards.*' => ['exists:hunt_rewards,id'],
            'action' => ['required', 'in:enable,disable'],
        ]);

        $enabled = $request->input('action') === 'enable';
        $count = HuntReward::whereIn('id', $request->input('rewards'))
            ->update(['is_enabled' => $enabled]);

        $message = $enabled
            ? trans('hunt::admin.rewards.status.bulk_enabled', ['count' => $count])
            : trans('hunt::admin.rewards.status.bulk_disabled', ['count' => $count]);

        return back()->with('success', $message);
    }
}
