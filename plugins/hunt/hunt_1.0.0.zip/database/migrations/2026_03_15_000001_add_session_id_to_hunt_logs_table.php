<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hunt_logs', function (Blueprint $table) {
            $table->string('session_id', 191)->nullable()->after('ip_address');
            $table->index('session_id');
        });
    }

    public function down(): void
    {
        Schema::table('hunt_logs', function (Blueprint $table) {
            $table->dropIndex(['session_id']);
            $table->dropColumn('session_id');
        });
    }
};
