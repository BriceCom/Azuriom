<!DOCTYPE html>
@include('elements.base')
@php
    $version_theme = '1.1';

    $totalPlayers = $servers->where('home_display', true)->sum(function($server) {
        return $server->isOnline() ? $server->getOnlinePlayers() : 0;
    });
@endphp
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
{{--    <x-seolite::providers.seolite/>--}}
    <meta charset="utf-8">
    <meta name="robots" content="follow, index, all"/>
    <link rel="canonical" href="{{url()->current()}}">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="@yield('description', setting('description', ''))">
    <meta name="author" content="Azuriom, Dixept">
    <meta name="publisher" content="{{site_name()}}, Dixept">

    <link rel="apple-touch-icon" sizes="180x180" href="{{ favicon() }}">
    <link rel="icon" href="{{ favicon() }}" sizes="32x32">
    <link rel="shortcut icon" href="{{ favicon() }}">
    <meta name="msapplication-TileImage" content="{{ favicon() }}">
    <meta name="msapplication-TileColor" content="#3490DC">

    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="{{'@'.site_name()}}">
    <meta name="twitter:creator" content="{{'@'.site_name()}}">
    <meta name="twitter:creator:id" content="{{'@'.site_name()}}">
    <meta name="twitter:title" content="{{site_name()}} | @yield('title')">
    <meta name="twitter:description" content="@yield('description', setting('description', ''))">
    <meta name="twitter:image" content="{{ favicon() }}">

    <meta property="og:title" content="@yield('title')">
    <meta property="og:type" content="@yield('type', 'website')">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:image" content="{{ favicon() }}">
    <meta property="og:image:alt" content="{{site_name()}}">
    <meta property="og:description" content="@yield('description', setting('description', ''))">
    <meta property="og:site_name" content="{{ site_name() }}">
    @stack('meta')

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title') | {{ site_name() }}</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ favicon() }}">

    <!-- Scripts -->
    <script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}" defer></script>
    <script src="{{ asset('vendor/axios/axios.min.js') }}" defer></script>
    <script src="{{ asset('js/script.js') }}" defer></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- Page level scripts -->
    @stack('scripts')

    <!-- Fonts -->
    <link href="{{ asset('vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">

    <!-- Styles -->
    @include('layouts/styles')

    <link rel="stylesheet" href="{{ theme_asset('css/override-bootstrap.css').'?ver='.$version_theme }}">
    <link rel="stylesheet" href="{{ theme_asset('css/styles.css').'?ver='.$version_theme }}">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    @stack('styles')
    <style>
        @if(theme_config('premium.serveurliste.link') && theme_config('style.index.font.on'))
            @import url({{theme_config('style.index.font.url') ?? 'https://fonts.bunny.net/css?family=poppins:200,300,400,500,600,700,800&display=swap'}});

            :root {
                --di-main-font: "{{theme_config('style.index.font.name') ?? 'poppins'}}", sans-serif;

            }
        @endif
    </style>
    <script type="text/javascript">
        window.THEME = {
            discord_key: "{{theme_config('settings.discord.id') ?? '1025845189115400303'}}",
            server_online: {{ $totalPlayers }},
            particles: {
                enabled: {{ theme_config('settings.index.particles.enabled', false) ? 'true' : 'false' }},
                count: {{ theme_config('settings.index.particles.count') ?? 10 }},
                density: {{ theme_config('settings.index.particles.density') ?? 800 }},
                speed: {{ theme_config('settings.index.particles.speed') ?? 1 }},
                size: {{ theme_config('settings.index.particles.size') ?? 3 }},
                image: "{{ theme_config('settings.index.particles.image') ? image_url(theme_config('settings.index.particles.image')) : '' }}",
                color: 'rgba(255, 255, 255, 0.9)'
            }
        }
    </script>

    <script src="{{ theme_asset('js/discord.js') }}" defer></script>
    <script src="{{ theme_asset('js/particles.js') }}" defer></script>
</head>

<body
    @if(!theme_config('style.index.theme.dark.off'))
        @php($defaultDark = (bool)theme_config('style.index.theme.dark.prefer'))

        @if(dark_theme($defaultDark))
            data-bs-theme="dark"
    @else
        data-bs-theme="light"
    @endif
    @else
        @if(theme_config('style.index.theme.dark.prefer'))
            data-bs-theme="dark"
    @else
        data-bs-theme="light"
    @endif
    @endif
>
<div id="app">
    @include('elements.header.page-height-bar')

    @include('elements.navbar')

    <div class="d-flex flex-column">
        @yield('app')

        @include('elements.footer.footer')
    </div>
</div>

@include('components.oauth.oauth-script')
@stack('footer-scripts')

<script src="{{ theme_asset('js/app.js').'?ver='.$version_theme }}"></script>
<script src="{{ theme_asset('js/counters.js') }}"></script>
<script src="{{ theme_asset('js/copyboard.js') }}"></script>

<script>
    document.querySelectorAll('.card').forEach((el, index) => {
        el.setAttribute('data-aos', 'fade-up');
        el.setAttribute('data-aos-delay', `${index * 100}`);
        el.setAttribute('data-aos-offset', '0');
    });

    AOS.init({
        duration: 700,
        once: true
    });
</script>

</body>
</html>
