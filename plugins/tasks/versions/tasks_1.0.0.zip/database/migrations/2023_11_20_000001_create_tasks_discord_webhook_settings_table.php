<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tasks_discord_webhook_settings', function (Blueprint $table) {
            $table->id();
            $table->string('webhook_url')->nullable();
            $table->boolean('enabled')->default(false);

            // Event-specific webhook URLs and toggles
            $table->string('webhook_url_created')->nullable();
            $table->boolean('send_on_created')->default(false);

            $table->string('webhook_url_started')->nullable();
            $table->boolean('send_on_started')->default(false);

            $table->string('webhook_url_completed')->nullable();
            $table->boolean('send_on_completed')->default(false);

            $table->string('webhook_url_archived')->nullable();
            $table->boolean('send_on_archived')->default(false);

            $table->string('webhook_url_comment')->nullable();
            $table->boolean('send_on_comment')->default(false);

            $table->string('webhook_url_logs')->nullable();
            $table->boolean('send_on_logs')->default(false);

            // Customization
            $table->string('color_created')->default('#00ff00');
            $table->string('color_started')->default('#0099ff');
            $table->string('color_completed')->default('#00ff00');
            $table->string('color_archived')->default('#666666');
            $table->string('color_comment')->default('#ff9900');
            $table->string('color_logs')->default('#ff00ff');

            // Webhook appearance
            $table->string('custom_username')->nullable();
            $table->string('custom_avatar_url')->nullable();

            // Content display options
            $table->boolean('show_author')->default(true);
            $table->boolean('show_assignees')->default(true);
            $table->boolean('show_tags')->default(true);
            $table->boolean('show_description')->default(true);
            $table->integer('description_length')->default(200);

            // Templates (removed ->after())
            $table->text('template_created')->nullable();
            $table->text('template_started')->nullable();
            $table->text('template_completed')->nullable();
            $table->text('template_archived')->nullable();
            $table->text('template_comment')->nullable();
            $table->text('template_logs')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tasks_discord_webhook_settings');
    }
};
