<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('hunt_hunts', function (Blueprint $table) {
            $table->integer('spawn_delay_seconds')->default(0)->after('cooldown_minutes');
        });
    }
    public function down(): void
    {
        Schema::table('hunt_hunts', function (Blueprint $table) {
            $table->dropColumn('spawn_delay_seconds');
        });
    }
};
