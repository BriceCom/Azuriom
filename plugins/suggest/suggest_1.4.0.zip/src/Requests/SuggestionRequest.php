<?php

namespace Azuriom\Plugin\Suggest\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SuggestionRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $maxDescriptionLength = setting('suggest.max_description_length', 600);

        $rules = [
            'title' => ['required', 'string', 'max:80'],
            'content' => ['required', 'string', 'max:' . $maxDescriptionLength],
            'category_id' => ['required', 'exists:suggest_categories,id'],
        ];

        if ($this->routeIs('suggest.admin.*')) {
            $rules['status'] = ['required', 'string', 'in:pending,approved,rejected'];
            $rules['refusal_reason'] = ['nullable', 'string'];
        }

        return $rules;
    }

}
