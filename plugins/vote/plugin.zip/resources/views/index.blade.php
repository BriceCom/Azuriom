@extends('layouts.app')

@section('title', trans('vote::messages.title'))

@section('content')
    <h1>{{ trans('vote::messages.sections.vote') }}</h1>

    <div class="card mb-4">
        <div class="card-body text-center position-relative" id="vote-card">
            <div class="spinner-parent h-100">
                <div class="spinner-border text-white" role="status"></div>
            </div>

            <div class="@auth d-none @endauth" data-vote-step="1">
                <form class="row justify-content-center" action="{{ route('vote.verify-user', '/') }}" id="voteNameForm">
                    @include('vote::_components.session-user')
                </form>
            </div>

            <div class="@guest d-none @endguest h-100" data-vote-step="2">
                @php
                    $knownVoteNameForPanel = $sessionVoteName ?? (isset($user) && $user !== null ? $user->name : null);
                    $hasKnownVoteName = isset($knownVoteNameForPanel) && $knownVoteNameForPanel !== '';
                @endphp

                @include('vote::_components.known-session-user', [
                    'containerId' => 'vote-session-known-step2',
                    'containerClass' => 'w-full mb-3',
                    'knownVoteName' => $knownVoteNameForPanel,
                    'isVisible' => $hasKnownVoteName,
                    'avatarId' => 'vote-session-avatar-step2',
                    'nameId' => 'vote-session-name-step2'
                ])

                @forelse($sites as $site)
                    <a class="btn btn-primary" href="{{ $site->url }}" target="_blank" rel="noopener noreferrer"
                       data-vote-id="{{ $site->id }}"
                       data-vote-url="{{ route('vote.vote', $site) }}"
                       @auth data-vote-time="{{ $site->getNextVoteTime($user, $request)?->valueOf() }}" @endauth>
                        <span class="badge bg-secondary text-white vote-timer"></span> {{ $site->name }}
                    </a>
                @empty
                    <div class="alert alert-warning" role="alert">
                        {{ trans('vote::messages.errors.site') }}
                    </div>
                @endforelse
            </div>

            <div class="d-none" data-vote-step="3">
                <p id="vote-result"></p>
            </div>

            <div class="d-none" data-vote-step="server">
                <p>{{ trans('vote::messages.server') }}</p>

                <div id="server-select"></div>
            </div>
        </div>
    </div>

    @if($goalEnabled)
        <div class="card mb-4" id="vote-goal">
            <div class="card-body">
                <h2 class="card-title">
                    {{ trans('vote::messages.sections.goal') }}
                </h2>

                <div class="progress mb-1">
                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                         role="progressbar"
                         style="width: {{ min($goalPercentage, 100) }}%"
                         aria-valuenow="{{ $goalProgress }}"
                         aria-valuemin="0"
                         aria-valuemax="{{ $goalTarget }}">
                    </div>
                </div>

                <p class="text-center mb-0" id="goal-text">
                    {{ trans('vote::messages.goal', ['current' => $goalProgress, 'target' => $goalTarget]) }}
                </p>
            </div>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            <h2 class="card-title">
                {{ trans('vote::messages.sections.top') }}
            </h2>

            <table class="table mb-0" id="vote-top-table">
                <thead class="table-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">{{ trans('messages.fields.name') }}</th>
                    <th scope="col" class="text-end">{{ trans('vote::messages.fields.votes') }}</th>
                </tr>
                </thead>
                <tbody>

                @foreach($votes as $id => $vote)
                    <tr>
                        <th scope="row">#{{ $id }}</th>
                        <td>{{ $vote->user->name }}</td>
                        <td class="text-end">{{ $vote->votes }}</td>
                    </tr>
                @endforeach

                </tbody>
            </table>

            @include('vote::_components.user-position')
        </div>
    </div>


    @if($displayRewards)
        <div class="card mt-4">
            <div class="card-body">
                <h2 class="card-title">
                    {{ trans('vote::messages.sections.rewards') }}
                </h2>

                <table class="table mb-0">
                    <thead class="table-dark">
                    <tr>
                        <th scope="col">{{ trans('messages.fields.name') }}</th>
                        <th scope="col">{{ trans('vote::messages.fields.chances') }}</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach($rewards as $reward)
                        <tr>
                            <th scope="row">
                                @if($reward->image)
                                    <img src="{{ $reward->imageUrl() }}" alt="{{ $reward->name }}" width="45">
                                @endif
                                {{ $reward->name }}
                            </th>
                            <td>{{ $reward->chances }} %</td>
                        </tr>
                    @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    @endif

@endsection

@push('scripts')
    @if($ipv6compatibility)
        <script src="https://cdn.ipv6-adapter.com/v1/api.js" async defer></script>
    @endif

    <script src="{{ plugin_asset('vote', 'js/vote.js?v3') }}" defer></script>
    @auth
        <script>
            window.username = '{{ $user->name }}';
        </script>
    @endauth
@endpush

@push('styles')
    <style>
        #vote-card .btn:not(:last-child) {
            margin-right: 0.5rem;
        }

        #vote-card .spinner-parent {
            display: none;
        }

        #vote-card.voting .spinner-parent {
            position: absolute;
            display: flex;
            align-items: center;
            justify-content: center;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(70, 70, 70, 0.6);
            z-index: 10;
        }
    </style>
@endpush
