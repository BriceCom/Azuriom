<?php

namespace Azuriom\Plugin\Tasks\Models;

use Azuriom\Models\Traits\HasTablePrefix;
use Illuminate\Database\Eloquent\Model;

class DiscordWebhookSetting extends Model
{
    use HasTablePrefix;

    /**
     * The table prefix associated with the model.
     */
    protected string $prefix = 'tasks_';

    /**
     * The table associated with the model.
     */
    protected $table = 'tasks_discord_webhook_settings';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'webhook_url',
        'enabled',
        'webhook_url_created',
        'send_on_created',
        'webhook_url_started',
        'send_on_started',
        'webhook_url_completed',
        'send_on_completed',
        'webhook_url_archived',
        'send_on_archived',
        'webhook_url_comment',
        'send_on_comment',
        'webhook_url_logs',
        'send_on_logs',
        'color_created',
        'color_started',
        'color_completed',
        'color_archived',
        'color_comment',
        'color_logs',
        'template_created',
        'template_started',
        'template_completed',
        'template_archived',
        'template_comment',
        'template_logs',
        'custom_username',
        'custom_avatar_url',
        'show_author',
        'show_assignees',
        'show_tags',
        'show_description',
        'description_length',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'enabled' => 'boolean',
        'send_on_created' => 'boolean',
        'send_on_started' => 'boolean',
        'send_on_completed' => 'boolean',
        'send_on_archived' => 'boolean',
        'send_on_comment' => 'boolean',
        'send_on_logs' => 'boolean',
        'show_author' => 'boolean',
        'show_assignees' => 'boolean',
        'show_tags' => 'boolean',
        'show_description' => 'boolean',
        'description_length' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the singleton instance of Discord webhook settings.
     * Creates a new record if none exists.
     */
    public static function getInstance(): self
    {
        $settings = self::first();

        if (!$settings) {
            $settings = self::create([
                'webhook_url' => null,
                'enabled' => false,
                'webhook_url_created' => null,
                'send_on_created' => false,
                'webhook_url_started' => null,
                'send_on_started' => false,
                'webhook_url_completed' => null,
                'send_on_completed' => false,
                'webhook_url_archived' => null,
                'send_on_archived' => false,
                'webhook_url_comment' => null,
                'send_on_comment' => false,
                'webhook_url_logs' => null,
                'send_on_logs' => false,
                'color_created' => '#00ff00',
                'color_started' => '#0099ff',
                'color_completed' => '#00ff00',
                'color_archived' => '#666666',
                'color_comment' => '#ff9900',
                'color_logs' => '#ff00ff',
                'custom_username' => null,
                'custom_avatar_url' => null,
                'show_author' => true,
                'show_assignees' => true,
                'show_tags' => true,
                'show_description' => true,
                'description_length' => 200,
            ]);
        }

        return $settings;
    }

    /**
     * Check if webhooks are enabled.
     */
    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    /**
     * Check if webhook should be sent for the given action.
     */
    public function shouldSendForAction(string $action): bool
    {
        if (!$this->isEnabled()) {
            return false;
        }

        $webhookUrl = $this->getWebhookUrlForAction($action);
        if (empty($webhookUrl)) {
            if (empty($this->webhook_url)) {
                return false;
            }
        }

        return match ($action) {
            'created' => $this->send_on_created,
            'started' => $this->send_on_started,
            'completed' => $this->send_on_completed,
            'archived' => $this->send_on_archived,
            'restored' => $this->send_on_archived,
            'updated' => $this->send_on_logs,
            'comment' => $this->send_on_comment,
            'logs' => $this->send_on_logs,
            default => false,
        };
    }

    /**
     * Get the webhook URL for a specific action.
     * Falls back to the global webhook URL if no specific URL is set.
     */
    public function getWebhookUrlForAction(string $action): ?string
    {
        $specificUrl = match ($action) {
            'created' => $this->webhook_url_created,
            'started' => $this->webhook_url_started,
            'completed' => $this->webhook_url_completed,
            'archived' => $this->webhook_url_archived,
            'restored' => $this->webhook_url_archived,
            'updated' => $this->webhook_url_logs,
            'comment' => $this->webhook_url_comment,
            'logs' => $this->webhook_url_logs,
            default => null,
        };

        return $specificUrl ?: $this->webhook_url;
    }

    /**
     * Get the color for a specific action.
     */
    public function getColorForAction(string $action): string
    {
        return match ($action) {
            'created' => $this->color_created ?? '#00ff00',
            'started' => $this->color_started ?? '#0099ff',
            'completed' => $this->color_completed ?? '#00ff00',
            'archived' => $this->color_archived ?? '#666666',
            'restored' => $this->color_archived ?? '#666666',
            'updated' => $this->color_logs ?? '#ff00ff',
            'comment' => $this->color_comment ?? '#ff9900',
            'logs' => $this->color_logs ?? '#ff00ff',
            default => '#666666',
        };
    }

    /**
     * Get the default action text for a specific action.
     */
    public function getDefaultActionText(string $action): string
    {
        return match ($action) {
            'created' => trans('tasks::admin.logs.created'),
            'started' => trans('tasks::admin.settings.discord.event_started'),
            'completed' => trans('tasks::admin.settings.discord.event_completed'),
            'archived' => trans('tasks::admin.settings.discord.event_archived'),
            'restored' => trans('tasks::admin.logs.restored'),
            'updated' => trans('tasks::admin.logs.updated'),
            'comment' => trans('tasks::admin.settings.discord.event_comment'),
            'logs' => trans('tasks::admin.settings.discord.event_logs'),
            default => 'Task Update',
        };
    }

    /**
     * Get the template for a specific action.
     */
    public function getTemplateForAction(string $action): ?string
    {
        return match ($action) {
            'created' => $this->template_created,
            'started' => $this->template_started,
            'completed' => $this->template_completed,
            'archived' => $this->template_archived,
            'restored' => $this->template_archived,
            'updated' => $this->template_logs,
            'comment' => $this->template_comment,
            'logs' => $this->template_logs,
            default => null,
        };
    }

    /**
     * Replace variables in a template string.
     */
    public function replaceVariables(string $template, array $variables): string
    {
        foreach ($variables as $key => $value) {
            $template = str_replace('{' . $key . '}', $value, $template);
        }

        return $template;
    }
}
