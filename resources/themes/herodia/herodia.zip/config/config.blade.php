@extends('admin.layouts.admin')

@section('title', 'Herodia config')

@include('admin.elements.color-picker')

@push('footer-scripts')
    <script src="{{ theme_asset('js/config.js') }}"></script>
@endpush

@section('content')
    <div class="card shadow">
        <div class="card-body">
            <form action="{{ route('admin.themes.config', $theme) }}" method="POST">
                @csrf



                <div class="row g-3">
                    <div class="mb-3">
                        <label class="form-label" for="colorInput">{{ trans('theme::herodia.config.color') }}</label>
                        <input type="text" class="form-control @error('color') is-invalid @enderror" id="colorInput" name="color" value="{{ old('color', config('theme.color')) }}">

                        @error('color')
                        <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="backgroundInput">{{ trans('theme::herodia.config.background') }}</label>
                        <input type="text" class="form-control @error('background') is-invalid @enderror" id="backgroundInput" name="background" value="{{ old('background', config('theme.background')) }}">

                        @error('background')
                        <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="welcome_title">{{ trans('theme::herodia.config.welcome_title') }}</label>
                        <input type="text" class="form-control @error('welcome_title') is-invalid @enderror" id="welcome_title" name="welcome_title" value="{{ old('welcome_title', config('theme.welcome_title')) }}">

                        @error('welcome_title')
                        <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="welcome_text">{{ trans('theme::herodia.config.welcome_text') }}</label>
                        <input type="text" class="form-control @error('welcome_text') is-invalid @enderror" id="welcome_text" name="welcome_text" value="{{ old('welcome_text', config('theme.welcome_text')) }}">

                        @error('welcome_text')
                        <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label class="form-label" for="unique_players">{{ trans('theme::herodia.config.unique_players') }}</label>
                        <input type="text" class="form-control @error('unique_players') is-invalid @enderror" id="unique_players" name="unique_players" value="{{ old('unique_players', config('theme.unique_players')) }}">

                        @error('unique_players')
                        <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
                        @enderror
                    </div>

                    @include('admin.config.vote')
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-save"></i> {{ trans('messages.actions.save') }}
                </button>
            </form>
        </div>
    </div>
@endsection
