<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('hunt_rewards', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('hunt_id')->nullable();
            $table->string('name');
            $table->decimal('chances', 5, 2)->default(100.00);
            $table->decimal('money', 10, 2)->nullable();
            $table->json('commands')->nullable();
            $table->boolean('need_online')->default(false);
            $table->boolean('is_enabled')->default(true);
            $table->timestamps();

            $table->foreign('hunt_id')->references('id')->on('hunt_hunts')->onDelete('set null');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('hunt_rewards');
    }
};
